import { useState } from "react";
import "./App.css";

const phrases = [
  "No",
  "Whyyyyyyyyyyyy:(",
  "pls pls pls pls",
  "huhuhuhu pls",
  "say yes say yes",
  "k that's it imma cri",
  ":((((((",
];

function App() {
  const [noCount, setNoCount] = useState(0);
  const [yesPressed, setYesPressed] = useState(false);
  const yesButtonsize = noCount * 20 + 16;

  function handleNoClick() {
    setNoCount(noCount + 1);
  }

  function getNoButtonText() {
    return phrases[Math.min(noCount, phrases.length - 1)];
  }

  return (
    <div className="valentine-container">
      {yesPressed ? (
        <>
          <img
            alt="cat yey"
            src="https://media1.tenor.com/m/ufd0ItHQVaIAAAAC/mochi-mochimochi.gif"
          />
          <div className="text">Yay!!!!i love uuuu</div>
        </>
      ) : (
        <>
          <img
            alt="cat yesno"
            src="https://media1.tenor.com/m/NePMC50_Hp0AAAAC/yelynn-yelynnn-hun-hun.gif"
          />

          <div>Hi bb, will you be my valentine?</div>
          <div>
            <button
              className="yes-button"
              style={{ fontSize: yesButtonsize }}
              onClick={() => setYesPressed(true)}
            >
              Yes
            </button>
            <button onClick={handleNoClick} className="noButton">
              {getNoButtonText()}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default App;
